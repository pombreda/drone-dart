import 'package:unittest/html_config.dart';
import 'decimal_test.dart' as t;

main() {
  useHtmlConfiguration();
  t.main();
}
